export interface ApiResponse {
    comicId: string;
}

export interface ComicResponse {
    img: string;
    alt: string;
    safe_title: string;
    date: string;
}
